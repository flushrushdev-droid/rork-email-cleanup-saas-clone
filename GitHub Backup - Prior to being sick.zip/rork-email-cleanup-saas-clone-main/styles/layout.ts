export const rowText = {
	minWidth: 0,
	flexShrink: 1,
} as const;



